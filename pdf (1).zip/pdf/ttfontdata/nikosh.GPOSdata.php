<?php
$LuCoverage = array (
  0 => 
  array (
    0 => 
    array (
      2433 => 0,
    ),
  ),
  1 => 
  array (
    0 => 
    array (
      2433 => 0,
    ),
  ),
  2 => 
  array (
    0 => 
    array (
      57405 => 0,
    ),
  ),
  3 => 
  array (
    0 => 
    array (
      2497 => 0,
      2498 => 1,
      2499 => 2,
      2500 => 3,
      2530 => 4,
      2531 => 5,
    ),
  ),
  4 => 
  array (
    0 => 
    array (
      2497 => 0,
      2498 => 1,
    ),
  ),
  5 => 
  array (
    0 => 
    array (
      2433 => 0,
    ),
  ),
);
?>